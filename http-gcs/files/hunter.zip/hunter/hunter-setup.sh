#!/bin/bash

flag=0
eclipseflag=0
javaFlag=0

function pause {
    read -p "$*"
}

function eclipse-init {

    #create init script
    cd eclipse
    if [ $flag -gt 0 ]
    then  
	echo JAVA_HOME="$JAVA_HOME" > eclipse-start
	echo export PATH="$JAVA_HOME/bin:$PATH" >> eclipse-start
	echo "$PWD"/eclipse >> eclipse-start
    else 
	echo "$PWD"/eclipse > eclipse-start 
    fi  

    chmod +x eclipse-start

    #create desktop shortcut
    echo [Desktop Entry] > ~/Desktop/eclipse.desktop
    echo Name=Eclipse-Hunter >> ~/Desktop/eclipse.desktop
    echo Type=Application >> ~/Desktop/eclipse.desktop
    echo Exec=$PWD/eclipse-start >> ~/Desktop/eclipse.desktop
    echo Terminal=false >> ~/Desktop/eclipse.desktop
    echo Icon=$PWD/icon.xpm >> ~/Desktop/eclipse.desktop
    echo Comment=Integrated Development Environment >> ~/Desktop/eclipse.desktop
    echo NoDisplay=false >> ~/Desktop/eclipse.desktop
    echo Categories=Development >> ~/Desktop/eclipse.desktop
    echo Name[en]=Eclipse-Hunter >> ~/Desktop/eclipse.desktop

    chmod +x ~/Desktop/eclipse.desktop

    echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Eclipse has been installed $(tput setaf 2)successfully $(tput setaf 0)"
    echo "$(tput setaf 2)[Hunter] $(tput setaf 4)To run Eclipse, double click the $(tput setaf 2)Eclipse-Hunter$(tput setaf 4) icon in the Desktop $(tput sgr 0)"
}

function java-install {

    echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Installing Java...$(tput sgr 0)"
    read -r -p "$(tput setaf 2)[Hunter] $(tput setaf 4)Do you have root permissions? [Y/n] $(tput sgr 0)" response
    if [[ $response =~ ^([yY][eE][sS]|[yY])$ ]]
    then
	echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Updating package index via: $(tput setaf 2)\$ sudo apt-get update $(tput sgr 0)"
	read -r -p "$(tput setaf 2)[Hunter] $(tput setaf 4)Do you want to continue? [Y/n] $(tput sgr 0)" step1
	if [[ $step1 =~ ^([yY][eE][sS]|[yY])$ ]]; then
	    sudo apt-get update
	    echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Installing default Java JDK via: $(tput setaf 2)\$ sudo apt-get install default-jdk $(tput sgr 0)"
	    read -r -p "$(tput setaf 2)[Hunter] $(tput setaf 4)Do you want to continue? [Y/n] $(tput sgr 0)" step2
            if [[ $step2 =~ ^([yY][eE][sS]|[yY])$ ]]; then
		sudo apt-get install default-jdk
            else
		java-install
            fi
	else
	    java-install
	fi
    else 
	echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Installing Java locally at: $(tput setaf 2)$PWD/java $(tput sgr 0)"
	flag=1
	
	jdk_filename=jdk-7u80-linux-x64.tar.gz
	jdk=http://download.oracle.com/otn-pub/java/jdk/7u80-b15/$jdk_filename
	
	if [ ! -d "java" ]; then
	    mkdir java
	fi
	
	cd java
	echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Downloading $(tput setaf 2)Java JDK 1.7$(tput setaf 4)...$(tput sgr 0)"
	pause "$(tput setaf 2)[Hunter] $(tput setaf 4)Press [enter] key to continue... $(tput sgr 0)"

	wget --no-check-certificate --no-cookies --header "Cookie: oraclelicense=accept-securebackup-cookie" $jdk
	
	tar -xvf $jdk_filename
	rm $jdk_filename
	
	JAVA_HOME=$PWD/jdk1.7.0_80
	export PATH="$JAVA_HOME/bin:$PATH"
	cd ..

    fi
}

function eclipse-install {

    echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Downloading $(tput setaf 2)Eclipse Mars$(tput setaf 4)...$(tput sgr 0)"
    pause "$(tput setaf 2)[Hunter] $(tput setaf 4)Press [enter] key to continue... $(tput sgr 0)"
    
    eclipse_filename=eclipse-java-mars-1-linux-gtk-x86_64.tar.gz
    eclipse=http://eclipse.mirror.rafal.ca/technology/epp/downloads/release/mars/1/$eclipse_filename
    wget $eclipse
    tar -xvf $eclipse_filename
    rm $eclipse_filename
    
    eclipse-init

}

function java-check {

    echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Checking Java version...$(tput sgr 0)"
    if type -p java | grep -q java; then
	_java=java
    elif [[ -n "$JAVA_HOME" ]] && [[ -x "$JAVA_HOME/bin/java" ]];  then
	_java="$JAVA_HOME/bin/java"
    else
	echo "$(tput setaf 2)[Hunter] $(tput setaf 1)Warning: No java has been found.$(tput sgr 0)"
	eclipseFlag=1
	javaFlag=1
    fi
    
    if [[ "$_java" ]]; then
	version=$("$_java" -version 2>&1 | awk -F '"' '/version/ {print $2}')
	if [[ "$version" > "1.7" ]]; then
            echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Java version" $version "supports Hunter.$(tput sgr 0)"
	else
            echo "$(tput setaf 2)[Hunter] $(tput setaf 1)Warning: Java version " $version " needs to be updated.$(tput sgr 0)"
	    eclipseFlag=1
	    javaFlag=1
	fi
    fi

}

function ubuntu-check {

    # Determine OS platform
    UNAME=$(uname | tr "[:upper:]" "[:lower:]")
    # If Linux, try to determine specific distribution
    if [ "$UNAME" == "linux" ]; then
	# If available, use LSB to identify distribution
	if [ -f /etc/lsb-release -o -d /etc/lsb-release.d ]; then
            export DISTRO=$(lsb_release -i | cut -d: -f2 | sed s/'^\t'//)
	    # Otherwise, use release info file
	else
            export DISTRO=$(ls -d /etc/[A-Za-z]*[_-][rv]e[lr]* | grep -v "lsb" | cut -d'/' -f3 | cut -d'-' -f1 | cut -d'_' -f1)
	fi
    fi
    # For everything else (or if above failed), just use generic identifier
    [ "$DISTRO" == "" ] && export DISTRO=$UNAME
    unset UNAME
    if [ "$DISTRO" != "Ubuntu" ]; then
	echo "$(tput setaf 2)[Hunter] $(tput setaf 1)Error: Linux distribution is not Ubuntu.$(tput sgr 0)"
	exit
    else
	version=$(lsb_release -rs)
	if [[ "$version" < "14.04" ]] ; then
	    echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Warning: Ubuntu version $version is older than 14.04 LTS.$(tput sgr 0)"
	fi
    fi
}

function bit-check {
    
    arch=$(getconf LONG_BIT)
    if [[ $arch != 64 ]]
    then
	echo "$(tput setaf 2)[Hunter] $(tput setaf 4)Error: Operating System is not 64 bits.$(tput sgr 0)"
	exit
    fi
}

#check if OS is 64 bits
bit-check

#check if OS is Ubuntu
ubuntu-check

#check Java version and install Eclipse
java-check

#install java
if [[ "$javaFlag" = "1" ]]; then
    #Java needs to be installed
    java-install
fi

#install eclipse
if [[ "$eclipseFlag" = "1" ]]; then
    #Eclipse was not previously installed since the system did not have Java
    eclipse-install
else
    read -r -p "$(tput setaf 2)[Hunter] $(tput setaf 4)Do you want to install Eclipse Mars? [Y/n] $(tput sgr 0)" response
    if [[ $response =~ ^([yY][eE][sS]|[yY])$ ]]; then
	eclipse-install
    fi
fi
