package src;

import java.util.Vector;

public class Bresenham {

	//@ Draw line between two points using the bresenham algorithm
	public static void drawLine(int x1, int y1, int x2, int y2, Vector<Pair> result) {
		
	}
}
