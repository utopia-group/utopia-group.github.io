package src;

public class LCS {

	//@ Find the longest common subsequence between two strings
	public static String lcs(String first, String second){

	}
}
