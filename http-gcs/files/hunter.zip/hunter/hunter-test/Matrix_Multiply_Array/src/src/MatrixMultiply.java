package src;

public class MatrixMultiply {
	
	//@ Multiply two matrices
	public static double[][] multiply(double[][] first, double[][] second){
		
	}
}
