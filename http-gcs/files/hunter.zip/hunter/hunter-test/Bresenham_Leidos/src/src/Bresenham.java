package src;

import java.util.Vector;

public class Bresenham {

	//@ Draw line between (0,0) and a point using the bresenham algorithm
	public static void drawLine(int x, int y, Vector<Pair> result){
		
	}
}
