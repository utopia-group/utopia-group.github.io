package src;

import java.util.Vector;

public class MatrixMultiply {
	
	//@ Multiply two matrices
	public static void multiply(final Vector<Vector<Double>> first, final Vector<Vector<Double>> second,
			Vector<Vector<Double>> result) {
				
	}
}
